loadstring(game:HttpGet("https://ghostbin.co/paste/yb6pdb/raw"))()
